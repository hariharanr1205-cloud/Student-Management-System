from rest_framework import serializers
from .models import Student


class StudentSerializer(serializers.ModelSerializer):
    """
    Handles both server-side validation (SOP section 9: mandatory fields,
    email format, numeric ranges, duplicate handling) and JSON
    representation for the REST API.
    """

    class Meta:
        model = Student
        fields = [
            'id', 'first_name', 'last_name', 'email', 'phone',
            'course', 'enrollment_date', 'gpa', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_first_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("First name cannot be empty.")
        return value.strip()

    def validate_last_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("Last name cannot be empty.")
        return value.strip()

    def validate_course(self, value):
        if not value.strip():
            raise serializers.ValidationError("Course cannot be empty.")
        return value.strip()

    def validate_gpa(self, value):
        if value < 0 or value > 4:
            raise serializers.ValidationError("GPA must be between 0.00 and 4.00.")
        return value
