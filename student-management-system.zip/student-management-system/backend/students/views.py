from rest_framework import viewsets, filters, status
from rest_framework.response import Response
from .models import Student
from .serializers import StudentSerializer


class StudentViewSet(viewsets.ModelViewSet):
    """
    Implements full CRUD (SOP section 7.6):
      GET    /api/students/        -> list (search/filter supported)
      POST   /api/students/        -> create
      GET    /api/students/{id}/   -> retrieve
      PUT    /api/students/{id}/   -> full update
      PATCH  /api/students/{id}/   -> partial update
      DELETE /api/students/{id}/   -> delete
    """
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['first_name', 'last_name', 'email', 'course']
    ordering_fields = ['first_name', 'last_name', 'enrollment_date', 'gpa']

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        self.perform_update(serializer)
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response({'message': 'Student deleted successfully.'}, status=status.HTTP_200_OK)
