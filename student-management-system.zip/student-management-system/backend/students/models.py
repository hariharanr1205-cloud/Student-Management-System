from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator
from django.db import models


class Student(models.Model):
    """
    Core entity for the Student Management System (SOP section 7.3:
    Database Design). Holds one record per enrolled student.
    """

    phone_validator = RegexValidator(
        regex=r'^\+?\d{7,15}$',
        message="Phone number must contain 7-15 digits, optionally starting with '+'."
    )

    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(unique=True)  # duplicate values rejected, per SOP section 9
    phone = models.CharField(max_length=16, validators=[phone_validator])
    course = models.CharField(max_length=100)
    enrollment_date = models.DateField()
    gpa = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        validators=[MinValueValidator(0.0), MaxValueValidator(4.0)],
        default=0.0,
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['last_name', 'first_name']

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.email})"
